﻿var data = [];

var dataStr = '1、朱超<br>\
<br>\
从大二时技术路上的小白，到如今成为对技术孜孜不倦的追求者，恍惚间，五年如一梦。<br>\
五年间，Jobsky给予我希望，教会我坚持，赋予我责任。<br>\
对于我而言，Jobsky已不仅是技术启蒙和学习的领路人，更是我大学生涯的陪伴者和守护者。<br>\
<br>\
<br>\
2、朱超<br>\
<br>\
Jobsky能革新不断、延续至今，我深以为最重要的不是优越的硬件环境，而是背后站着一个如家般温暖的、优秀的团队。<br>\
或许我们来自不同学院、不同的专业，但我们志趣相投，我们的身上标贴着一个共同的名字——Jobskyer，这足以让我们并肩奋斗！<br>\
<br>\
<br>\
3、朱超<br>\
<br>\
Jobsky能革新不断、延续至今，我深以为最重要的不是优越的硬件环境，而是背后站着一个如家般温暖的、优秀的团队。<br>\
或许我们来自不同学院、不同的专业，但我们志趣相投，我们的身上标贴着一个共同的名字——Jobskyer，这足以让我们并肩奋斗！<br>\
<br>\
<br>\
4、朱超<br>\
<br>\
我们不止是梦想家！我坚信，如果我们每个人都成长为一棵大树，那么Jobsky就是一片森林！<br>\
Fighting!!!Jobskyers!!!<br>\
<br>\
<br>\
5、曹琳<br>\
<br>\
在jobsky的每一天，我们共同努力，共同进步，相信通过一届又一届员工的不懈奋斗，jobsky的明天会更加灿烂辉煌!<br>\
<br>\
<br>\
6、曹琳<br>\
<br>\
在jobsky的每一天，我们共同努力，共同进步，相信通过一届又一届员工的不懈奋斗，jobsky的明天会更加灿烂辉煌!<br>\
<br>\
<br>\
7、曹琳<br>\
<br>\
在jobsky的每一天，我们共同努力，共同进步，相信通过一届又一届员工的不懈奋斗，jobsky的明天会更加灿烂辉煌!<br>\
<br>\
<br>\
8、高叶润<br>\
<br>\
每个员工都将成为大触！<br>\
<br>\
<br>\
9、高叶润<br>\
<br>\
每个员工都将成为大触！<br>\
<br>\
<br>\
10、黄昕琦<br>\
<br>\
就业网是个很让人成长的地方，希望大家能在这里实现内心所描绘的蓝图。<br>\
<br>\
<br>\
11、黄昕琦<br>\
<br>\
就业网是个很让人成长的地方，希望大家能在这里实现内心所描绘的蓝图。<br>\
<br>\
<br>\
12、金钰<br>\
<br>\
生命不息，奋斗不止，从网站的小鬼变成网站的小兵，网站与每一个jobskier共成长～愿大家走在时代前端，共创辉煌为网站而战，也为自己而战～<br>\
<br>\
<br>\
13、金钰<br>\
<br>\
生命不息，奋斗不止，从网站的小鬼变成网站的小兵，网站与每一个jobskier共成长～愿大家走在时代前端，共创辉煌为网站而战，也为自己而战～<br>\
<br>\
<br>\
14、娄方旭<br>\
<br>\
生活，是一种态度！<br>\
<br>\
<br>\
15、基友一对三缺一<br>\
<br>\
生活，是一种态度！<br>\
祝愿jobsky青春永驻，江山代有才人出；jobskyer友谊地久天长<br>\
<br>\
<br>\
16、娄方旭<br>\
<br>\
生活，是一种态度！<br>\
<br>\
<br>\
17、石晴蔚<br>\
<br>\
开春了，新年新气象，祝网站越办越好，祝大家实现梦想！<br>\
<br>\
<br>\
18、石晴蔚<br>\
<br>\
开春了，新年新气象，祝网站越办越好，祝大家实现梦想！<br>\
<br>\
<br>\
19、舒超<br>\
<br>\
Wishing to be sincere in their thoughts, they first extended to the utmost of their knowledge.<br>\
<br>\
<br>\
20、舒超<br>\
<br>\
The Great Learning , which is one of charpters of The book of Rites originally, is one of the “Four Books” in Confucianism. <br>\
<br>\
<br>\
21、舒超<br>\
<br>\
Wishing to order well their States, they first regulated their families.<br>\
Wishing to regulate their families, they first cultivated their persons.<br>\
Wishing to cultivate their persons, they first rectified their hearts.<br>\
Wishing to rectify their hearts, they first sought to be sincere in their thoughts.<br>\
<br>\
<br>\
22、谢宇珊<br>\
<br>\
新的一年希望我们就业网越办越好啦，希望网站能够被更多人知道和使用，也希望我们大家都能够与网站在这里一起成长！所有人都开心！get it！<br>\
<br>\
<br>\
23、张迪源<br>\
<br>\
祝愿jobsky青春永驻，江山代有才人出；jobskyer友谊地久天长<br>\
<br>\
<br>\
24、张迪源<br>\
<br>\
祝愿jobsky青春永驻，江山代有才人出；jobskyer友谊地久天长<br>\
<br>\
<br>\
25、张迪源<br>\
<br>\
祝愿jobsky青春永驻，江山代有才人出；jobskyer友谊地久天长<br>\
<br>\
<br>\
26、刘莹莹<br>\
<br>\
导演：彼得·杰克逊类型：动作 / 奇幻 / 冒险类型：动作 / 奇幻 / 冒险制片国家/地区：美国 / 新西兰语言：英语上映日期：2015-01-23(中国大陆) / 2014-12-17(美国)片长：144分钟<br>\
<br>\
<br>\
27、樱花<br>\
<br>\
导演：彼得·杰克逊类型：动作 / 奇幻 / 冒险类型：动作 / 奇幻 / 冒险制片国家/地区：美国 / 新西兰语言：英语上映日期：2015-01-23(中国大陆) / 2014-12-17(美国)片长：144分钟<br>\
<br>\
<br>\
28、支梦颖<br>\
<br>\
在实践中学习，在交流中成长，在网站这个大家庭里，收获了很多!<br>\
<br>\
<br>\
29、支梦颖<br>\
<br>\
在实践中学习，在交流中成长，在网站这个大家庭里，收获了很多!<br>\
<br>\
<br>\
30、钟浩宇<br>\
<br>\
网站在去年改版，发生了巨大变化。祝网站今年继续扩大影响力，扩大受众。希望网站技术部的所有成员一起加油。<br>\
<br>\
<br>\
31、钟浩宇<br>\
<br>\
同时这学期完了一些学长学姐们就要离开这里了，希望学长学姐们在职场能够早日出任CEO，迎娶白富美/高富帅！又要迎来新的成员啦，希望网站能继续保持活力与激情，为未来网站发展奠基！<br>\
';
var d = dataStr.split('<br><br><br>')
for (var i = 0; i < d.length; i++) {
    var c = d[i].split('<br><br>');
    data.push({
        img: c[0].replace('、', ' ') + '.jpg',
        caption: c[0].split('、')[1],
        desc: c[1]
    });
    console.log(c[0].replace('、', '') + '.jpg');
};
//照片翻转
// JavaScript Document